import React from 'react';
import MovieList from './MovieList';
import MusicList from './MusicList';

function App() {
  return <MovieList />;
}

export default App;
